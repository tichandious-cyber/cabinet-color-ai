import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image/image.dart' as img;
import 'package:google_mlkit_subject_segmentation/google_mlkit_subject_segmentation.dart';

void main() => runApp(const CabinetApp());

class CabinetApp extends StatelessWidget {
  const CabinetApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Cabinet Color AI',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF24312E)),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  File? original;
  Uint8List? resultBytes;
  Color selected = const Color(0xFFE8E2D6);
  double strength = .78;
  double threshold = .50;
  bool aiMode = true;
  bool busy = false;
  String status = 'یک عکس از کابینت انتخاب کن';

  final colors = const [
    Color(0xFFF7F3EA), Color(0xFFE8E2D6), Color(0xFFD4C4B4),
    Color(0xFFB7B1A8), Color(0xFF8A8D86), Color(0xFF3A3D3B),
    Color(0xFF171A1A), Color(0xFF263C34), Color(0xFF41685B),
    Color(0xFF3B5B72), Color(0xFF9A6848), Color(0xFF70452F),
  ];

  Future<void> pick(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, imageQuality: 95);
    if (x == null) return;
    setState(() {
      original = File(x.path);
      resultBytes = null;
      status = 'عکس آماده است';
    });
  }

  Future<void> applyAI() async {
    if (original == null || busy) return;
    setState(() { busy = true; status = 'در حال تشخیص سوژه…'; });

    final segmenter = SubjectSegmenter(
      options: SubjectSegmenterOptions(
        enableForegroundBitmap: true,
        enableForegroundConfidenceMask: true,
        enableMultipleSubjects: SubjectResultOptions(
          enableConfidenceMask: true,
          enableSubjectBitmap: true,
        ),
      ),
    );

    try {
      final input = InputImage.fromFilePath(original!.path);
      final res = await segmenter.processImage(input);
      final bytes = await original!.readAsBytes();
      final base = img.decodeImage(bytes);
      if (base == null) throw Exception('image decode failed');

      List<double>? mask = res.foregroundConfidenceMask;
      int mw = base.width, mh = base.height;

      // Prefer the largest detected subject mask when available.
      if (res.subjects.isNotEmpty) {
        final largest = [...res.subjects]
          ..sort((a,b) => (b.width*b.height).compareTo(a.width*a.height));
        final s = largest.first;
        if (s.confidenceMask != null && s.confidenceMask!.isNotEmpty) {
          mask = s.confidenceMask;
          mw = s.width;
          mh = s.height;
        }
      }

      if (mask == null || mask.isEmpty) {
        throw Exception('no segmentation mask');
      }

      // If the selected subject mask is local to its bounding box, recolor
      // within that box. Otherwise use the full-image foreground mask.
      int offsetX = 0, offsetY = 0;
      if (res.subjects.isNotEmpty) {
        final largest = [...res.subjects]
          ..sort((a,b) => (b.width*b.height).compareTo(a.width*a.height));
        final s = largest.first;
        if (mw == s.width && mh == s.height) {
          offsetX = s.startX; offsetY = s.startY;
        }
      }

      final r = selected.red, g = selected.green, b = selected.blue;
      final maskW = mw, maskH = mh;
      for (int y=0; y<base.height; y++) {
        for (int x=0; x<base.width; x++) {
          final mx = x - offsetX, my = y - offsetY;
          if (mx < 0 || my < 0 || mx >= maskW || my >= maskH) continue;
          final i = my * maskW + mx;
          if (i >= mask.length) continue;
          final c = mask[i].clamp(0.0, 1.0);
          if (c < threshold) continue;
          final p = base.getPixel(x,y);
          final amount = (strength * c).clamp(0.0, 1.0);
          final nr = (p.r * (1-amount) + r * amount).round().clamp(0,255);
          final ng = (p.g * (1-amount) + g * amount).round().clamp(0,255);
          final nb = (p.b * (1-amount) + b * amount).round().clamp(0,255);
          base.setPixelRgba(x,y,nr,ng,nb,p.a);
        }
      }

      resultBytes = Uint8List.fromList(img.encodeJpg(base, quality: 94));
      status = 'پیش‌نمایش AI آماده است';
    } catch (e) {
      // Fallback is intentionally conservative: do not claim AI succeeded.
      status = 'تشخیص AI انجام نشد؛ عکس یا نور متفاوتی امتحان کن.';
      resultBytes = null;
    } finally {
      await segmenter.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> save() async {
    final data = resultBytes;
    if (data == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/cabinet_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await file.writeAsBytes(data);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ذخیره شد: ${file.path}')),
      );
    }
  }

  void setHex(String value) {
    var s = value.trim().replaceAll('#','');
    if (s.length == 6) s = 'FF$s';
    final n = int.tryParse(s, radix: 16);
    if (n != null) setState(() => selected = Color(n));
  }

  @override
  Widget build(BuildContext context) {
    final shown = resultBytes != null
      ? Image.memory(resultBytes!, fit: BoxFit.contain)
      : original != null
        ? Image.file(original!, fit: BoxFit.contain)
        : const Icon(Icons.kitchen_outlined, size: 82);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cabinet Color AI'),
        centerTitle: true,
        actions: [IconButton(onPressed: resultBytes == null ? null : save,
          icon: const Icon(Icons.download_rounded))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('رنگ کابینت را قبل از اجرا ببین',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(status, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 14),
          Container(
            height: 330,
            decoration: BoxDecoration(
              color: Colors.black12, borderRadius: BorderRadius.circular(22)),
            clipBehavior: Clip.antiAlias,
            child: Center(child: shown),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: FilledButton.icon(
              onPressed: () => pick(ImageSource.gallery),
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('گالری'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => pick(ImageSource.camera),
              icon: const Icon(Icons.camera_alt_outlined),
              label: const Text('دوربین'))),
          ]),
          const SizedBox(height: 18),
          const Text('پالت رنگ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(spacing: 10, runSpacing: 10, children: colors.map((c) =>
            GestureDetector(
              onTap: () => setState(() => selected=c),
              child: Container(width: 46,height:46,
                decoration: BoxDecoration(
                  color:c, shape:BoxShape.circle,
                  border: Border.all(color: selected==c ? Colors.black : Colors.black26,
                    width:selected==c?4:1))),
            )).toList()),
          const SizedBox(height: 12),
          TextField(
            decoration: const InputDecoration(
              labelText: 'کد HEX رنگ',
              hintText: '#D8C8B7',
              border: OutlineInputBorder()),
            onSubmitted: setHex,
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تشخیص هوشمند'),
            subtitle: const Text('تلاش برای جدا کردن سوژه اصلی از پس‌زمینه'),
            value: aiMode, onChanged: (v)=>setState(()=>aiMode=v)),
          Text('شدت رنگ ${(strength*100).round()}%'),
          Slider(value:strength,min:.1,max:1,onChanged:(v)=>setState(()=>strength=v)),
          if (aiMode) ...[
            Text('آستانه ماسک ${(threshold*100).round()}%'),
            Slider(value:threshold,min:.2,max:.9,onChanged:(v)=>setState(()=>threshold=v)),
          ],
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: original == null || busy ? null : applyAI,
            icon: busy ? const SizedBox(width:20,height:20,
              child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.auto_awesome),
            label: Text(busy ? 'در حال پردازش…' : 'تشخیص و اعمال رنگ')),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: resultBytes == null ? null : save,
            icon: const Icon(Icons.save_alt),
            label: const Text('ذخیره نتیجه')),
          const SizedBox(height: 18),
          const Text('مدل‌های آماده کابینت', style: TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          SizedBox(height:82, child: ListView.separated(
            scrollDirection:Axis.horizontal,itemCount:5,
            separatorBuilder:(_,__)=>const SizedBox(width:10),
            itemBuilder:(_,i)=>Container(width:125,
              decoration:BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(16)),
              child:Center(child:Text('مدل ${i+1}'))))),
          const SizedBox(height:18),
          const Text(
            'نکته: مدل ML Kit سوژه‌های اصلی تصویر را جدا می‌کند؛ برای تشخیص دقیق «فقط کابینت» باید در مرحله بعد مدل segmentation اختصاصی کابینت آموزش داده شود.',
            style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
