# Cabinet Color AI — Android

نسخه 2:
- عکس از دوربین/گالری
- پالت و HEX
- شدت رنگ
- تشخیص سوژه با ML Kit روی خود دستگاه
- اعمال رنگ روی ماسک
- ذخیره خروجی
- آماده برای اضافه کردن مدل segmentation اختصاصی کابینت

## نکته فنی
ML Kit Subject Segmentation یک مدل عمومی برای جداسازی سوژه‌های اصلی است، نه یک مدل اختصاصی کابینت. بنابراین این نسخه «AI-assisted» است و ممکن است در آشپزخانه‌های شلوغ بخشی از اشیای دیگر را هم انتخاب کند.

برای نسخه تجاری دقیق، یک مدل segmentation اختصاصی کابینت (TFLite) باید با تصاویر برچسب‌گذاری‌شده کابینت آموزش داده شود و جایگزین ماسک عمومی شود.

## اجرا
flutter pub get
flutter run

## APK
flutter build apk --release

## Build رایگان با GitHub Actions
فایل `.github/workflows/android.yml` هر push را build می‌کند و APK را به عنوان artifact ذخیره می‌کند.
